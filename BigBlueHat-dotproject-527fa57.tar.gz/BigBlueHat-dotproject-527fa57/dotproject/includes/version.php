<?php

if (!defined('DP_BASE_DIR')) {
	die('You should not access this file directly.');
}
// Set the version components separately.
$dp_version_major = 2;
$dp_version_minor = 1;
$dp_version_patch = 3;	// Can be set to null if not used
$dp_version_prepatch = null;	// Set to null if a release version.
?>
