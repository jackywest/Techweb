<?php /* PROJECTS $Id$ */
if (!defined('DP_BASE_DIR')) {
  die('You should not access this file directly');
}

$m = 'history';
require(DP_BASE_DIR . '/modules/history/index.php');
?>
