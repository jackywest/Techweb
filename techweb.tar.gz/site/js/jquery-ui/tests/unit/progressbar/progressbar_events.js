/*
 * progressbar_events.js
 */
(function($) {

module("progressbar: events");

test("change", function() {
	ok(false, "missing test - untested code is broken code.");
});

})(jQuery);
