<?php
require 'smarty/libs/Smarty.class.php';

$smarty = new Smarty;
$smarty->display('login.tpl');
?>